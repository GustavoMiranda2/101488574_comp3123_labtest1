# COMP3123 - Lab Test 1

**Nome:** Gustavo Miranda  
**Student ID:** 101488574  

---